"""
===============================================================================
Mini-WireGuard: Performance & Overhead Benchmark Tool
===============================================================================
Role:
    Addresses Deliverable 4 and Milestone 88 from the BACSE203 Project Handbook.
    Quantifies the latency and throughput overhead introduced by Mini-WireGuard's
    Layer 3 TUN encapsulation and ChaCha20-Poly1305 AEAD authenticated encryption.

Metrics Measured:
    1. Direct Wi-Fi Latency (ICMP RTT) vs Tunneled Latency (10.8.0.1)
    2. Direct Wi-Fi Throughput vs Tunneled Throughput (via iperf3)
    3. Packet Encapsulation Overhead breakdown

Usage:
    python benchmark.py --direct-ip <SERVER_WIFI_IP> [--vpn-ip 10.8.0.1]
===============================================================================
"""

import argparse
import re
import shutil
import subprocess
import sys


def measure_ping_rtt(target_ip: str, count: int = 5) -> float | None:
    """Sends ICMP echo requests on Windows and extracts average RTT in ms."""
    print(f"[*] Pinging {target_ip} ({count} packets)...")
    res = subprocess.run(["ping", "-n", str(count), target_ip], capture_output=True, text=True)
    if res.returncode != 0:
        return None

    # Parse Windows ping output: "Average = 4ms" or "Average = 4 ms"
    match = re.search(r"Average\s*=\s*(\d+)\s*ms", res.stdout, re.IGNORECASE)
    if match:
        return float(match.group(1))
    return None


def measure_iperf3_bandwidth(server_ip: str, duration: int = 5) -> float | None:
    """Runs iperf3 client and parses the resulting bandwidth in Mbits/sec."""
    iperf_path = shutil.which("iperf3")
    if not iperf_path:
        print("[!] iperf3 executable not found in PATH.")
        print("    (Download iperf3 for Windows to run automated throughput benchmarks)")
        return None

    print(f"[*] Running iperf3 client targeting {server_ip} for {duration} seconds...")
    res = subprocess.run([iperf_path, "-c", server_ip, "-t", str(duration), "-f", "m"], capture_output=True, text=True)
    if res.returncode != 0:
        return None

    # Parse iperf3 output line: "sender ... X.XX Mbits/sec"
    matches = re.findall(r"(\d+(?:\.\d+)?)\s*Mbits/sec", res.stdout)
    if matches:
        return float(matches[-1])
    return None


def main():
    parser = argparse.ArgumentParser(description="Mini-WireGuard Latency and Throughput Benchmark")
    parser.add_argument("--direct-ip", required=True, help="Physical Wi-Fi IP of Server (e.g. 192.168.211.23)")
    parser.add_argument("--vpn-ip", default="10.8.0.1", help="Virtual VPN IP of Server (default: 10.8.0.1)")
    parser.add_argument("--iperf", action="store_true", help="Run iperf3 bandwidth tests (requires iperf3 server running on target)")
    args = parser.parse_args()

    print("=" * 72)
    print(" [BACSE203 EVALUATION] Mini-WireGuard Overhead Benchmarking")
    print("=" * 72)
    print(f" Direct Server Endpoint  : {args.direct_ip}")
    print(f" Tunneled VPN Endpoint   : {args.vpn_ip}")
    print("=" * 72 + "\n")

    # 1. Latency Measurement (ICMP RTT)
    print("--- 1. Latency Overhead Measurement (ICMP Ping) ---")
    direct_rtt = measure_ping_rtt(args.direct_ip, count=10)
    vpn_rtt = measure_ping_rtt(args.vpn_ip, count=10)

    # 2. Throughput Measurement (Optional iperf3)
    direct_bw = None
    vpn_bw = None
    if args.iperf:
        print("\n--- 2. Throughput Measurement (iperf3) ---")
        direct_bw = measure_iperf3_bandwidth(args.direct_ip, duration=5)
        vpn_bw = measure_iperf3_bandwidth(args.vpn_ip, duration=5)

    # 3. Protocol Overhead Calculation
    encap_header_bytes = 1 + 4 + 8  # Type (1B) + SessionID (4B) + Nonce Counter (8B)
    auth_tag_bytes = 16            # Poly1305 MAC Tag
    total_crypto_overhead = encap_header_bytes + auth_tag_bytes
    standard_mtu = 1500
    effective_mtu = standard_mtu - total_crypto_overhead - 28  # 20B IPv4 + 8B UDP header
    overhead_pct = (total_crypto_overhead / standard_mtu) * 100

    # 4. Print Academic Evaluation Summary Table
    print("\n" + "=" * 72)
    print("                   BENCHMARK & OVERHEAD RESULTS REPORT")
    print("=" * 72)
    print(f"{'Metric':<30} | {'Direct (Plain)':<18} | {'Tunneled (Mini-WG)':<18}")
    print("-" * 72)

    if direct_rtt is not None and vpn_rtt is not None:
        delta_rtt = vpn_rtt - direct_rtt
        print(f"{'Average Latency (RTT)':<30} | {direct_rtt:.2f} ms{'':<11} | {vpn_rtt:.2f} ms (+{delta_rtt:.2f} ms)")
    else:
        print(f"{'Average Latency (RTT)':<30} | {'Check connectivity':<18} | {'Check tunnel':<18}")

    if direct_bw is not None and vpn_bw is not None:
        ratio = (vpn_bw / direct_bw) * 100 if direct_bw > 0 else 0
        print(f"{'Throughput (TCP)':<30} | {direct_bw:.2f} Mbits/sec{'':<5} | {vpn_bw:.2f} Mbits/sec ({ratio:.1f}%)")

    print("-" * 72)
    print(f"{'Wire Encapsulation Overhead':<30} | {'0 bytes':<18} | {total_crypto_overhead} bytes / datagram")
    print(f"{'Effective MTU (from 1500)':<30} | {'1500 bytes':<18} | {effective_mtu} bytes")
    print(f"{'Cryptographic Header Tax':<30} | {'0.00%':<18} | {overhead_pct:.2f}% of standard MTU")
    print("=" * 72)


if __name__ == "__main__":
    main()

